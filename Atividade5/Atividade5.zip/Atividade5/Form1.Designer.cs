﻿namespace Atividade5
{
    partial class CalculoSalario
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.cmboxFilhos = new System.Windows.Forms.ComboBox();
            this.mtxtSalario = new System.Windows.Forms.MaskedTextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.gBoxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnMasculino = new System.Windows.Forms.RadioButton();
            this.rbtnFeminino = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cboxCasado = new System.Windows.Forms.CheckBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.lblDados = new System.Windows.Forms.Label();
            this.lblAInss = new System.Windows.Forms.Label();
            this.lblAIRPF = new System.Windows.Forms.Label();
            this.lblSalFam = new System.Windows.Forms.Label();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.lblDINSS = new System.Windows.Forms.Label();
            this.lblDIRPF = new System.Windows.Forms.Label();
            this.txtAINSS = new System.Windows.Forms.TextBox();
            this.txtAIRPF = new System.Windows.Forms.TextBox();
            this.txtDINSS = new System.Windows.Forms.TextBox();
            this.txtDIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFam = new System.Windows.Forms.TextBox();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.gBoxSexo.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(100, 52);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(108, 13);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Nome do Funcionário";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(100, 82);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(67, 13);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "Salário Bruto";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(100, 118);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(34, 13);
            this.lbl3.TabIndex = 2;
            this.lbl3.Text = "Filhos";
            // 
            // cmboxFilhos
            // 
            this.cmboxFilhos.FormattingEnabled = true;
            this.cmboxFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.cmboxFilhos.Location = new System.Drawing.Point(228, 115);
            this.cmboxFilhos.Name = "cmboxFilhos";
            this.cmboxFilhos.Size = new System.Drawing.Size(100, 21);
            this.cmboxFilhos.TabIndex = 3;
            // 
            // mtxtSalario
            // 
            this.mtxtSalario.Location = new System.Drawing.Point(228, 82);
            this.mtxtSalario.Mask = "00000.00";
            this.mtxtSalario.Name = "mtxtSalario";
            this.mtxtSalario.Size = new System.Drawing.Size(100, 20);
            this.mtxtSalario.TabIndex = 4;
            this.mtxtSalario.ValidatingType = typeof(int);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(228, 49);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 20);
            this.txtNome.TabIndex = 5;
            // 
            // gBoxSexo
            // 
            this.gBoxSexo.Controls.Add(this.rbtnMasculino);
            this.gBoxSexo.Controls.Add(this.rbtnFeminino);
            this.gBoxSexo.Location = new System.Drawing.Point(448, 44);
            this.gBoxSexo.Name = "gBoxSexo";
            this.gBoxSexo.Size = new System.Drawing.Size(200, 100);
            this.gBoxSexo.TabIndex = 6;
            this.gBoxSexo.TabStop = false;
            this.gBoxSexo.Text = "Sexo";
            this.gBoxSexo.Enter += new System.EventHandler(this.gBoxSexo_Enter);
            // 
            // rbtnMasculino
            // 
            this.rbtnMasculino.AutoSize = true;
            this.rbtnMasculino.Location = new System.Drawing.Point(35, 71);
            this.rbtnMasculino.Name = "rbtnMasculino";
            this.rbtnMasculino.Size = new System.Drawing.Size(73, 17);
            this.rbtnMasculino.TabIndex = 1;
            this.rbtnMasculino.TabStop = true;
            this.rbtnMasculino.Text = "Masculino";
            this.rbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // rbtnFeminino
            // 
            this.rbtnFeminino.AutoSize = true;
            this.rbtnFeminino.Location = new System.Drawing.Point(35, 34);
            this.rbtnFeminino.Name = "rbtnFeminino";
            this.rbtnFeminino.Size = new System.Drawing.Size(67, 17);
            this.rbtnFeminino.TabIndex = 0;
            this.rbtnFeminino.TabStop = true;
            this.rbtnFeminino.Text = "Feminino";
            this.rbtnFeminino.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cboxCasado);
            this.panel1.Location = new System.Drawing.Point(448, 150);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 28);
            this.panel1.TabIndex = 7;
            // 
            // cboxCasado
            // 
            this.cboxCasado.AutoSize = true;
            this.cboxCasado.Location = new System.Drawing.Point(35, 8);
            this.cboxCasado.Name = "cboxCasado";
            this.cboxCasado.Size = new System.Drawing.Size(62, 17);
            this.cboxCasado.TabIndex = 0;
            this.cboxCasado.Text = "Casado";
            this.cboxCasado.UseVisualStyleBackColor = true;
            this.cboxCasado.CheckedChanged += new System.EventHandler(this.cboxCasado_CheckedChanged);
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(228, 154);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(75, 23);
            this.btnCalc.TabIndex = 8;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(321, 155);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 9;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(573, 394);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 10;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(103, 190);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(52, 13);
            this.lblDados.TabIndex = 11;
            this.lblDados.Text = "LblDados";
            // 
            // lblAInss
            // 
            this.lblAInss.AutoSize = true;
            this.lblAInss.Location = new System.Drawing.Point(103, 271);
            this.lblAInss.Name = "lblAInss";
            this.lblAInss.Size = new System.Drawing.Size(75, 13);
            this.lblAInss.TabIndex = 12;
            this.lblAInss.Text = "Alíquota INSS";
            // 
            // lblAIRPF
            // 
            this.lblAIRPF.AutoSize = true;
            this.lblAIRPF.Location = new System.Drawing.Point(103, 305);
            this.lblAIRPF.Name = "lblAIRPF";
            this.lblAIRPF.Size = new System.Drawing.Size(74, 13);
            this.lblAIRPF.TabIndex = 13;
            this.lblAIRPF.Text = "Alíquota IRPF";
            // 
            // lblSalFam
            // 
            this.lblSalFam.AutoSize = true;
            this.lblSalFam.Location = new System.Drawing.Point(100, 349);
            this.lblSalFam.Name = "lblSalFam";
            this.lblSalFam.Size = new System.Drawing.Size(76, 13);
            this.lblSalFam.TabIndex = 14;
            this.lblSalFam.Text = "Salário Família";
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Location = new System.Drawing.Point(378, 349);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(76, 13);
            this.lblSalLiq.TabIndex = 15;
            this.lblSalLiq.Text = "Salário Liquido";
            // 
            // lblDINSS
            // 
            this.lblDINSS.AutoSize = true;
            this.lblDINSS.Location = new System.Drawing.Point(378, 271);
            this.lblDINSS.Name = "lblDINSS";
            this.lblDINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDINSS.TabIndex = 16;
            this.lblDINSS.Text = "Desconto INSS";
            // 
            // lblDIRPF
            // 
            this.lblDIRPF.AutoSize = true;
            this.lblDIRPF.Location = new System.Drawing.Point(378, 305);
            this.lblDIRPF.Name = "lblDIRPF";
            this.lblDIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDIRPF.TabIndex = 17;
            this.lblDIRPF.Text = "Desconto IRPF";
            // 
            // txtAINSS
            // 
            this.txtAINSS.Enabled = false;
            this.txtAINSS.Location = new System.Drawing.Point(228, 271);
            this.txtAINSS.Name = "txtAINSS";
            this.txtAINSS.Size = new System.Drawing.Size(100, 20);
            this.txtAINSS.TabIndex = 18;
            // 
            // txtAIRPF
            // 
            this.txtAIRPF.Enabled = false;
            this.txtAIRPF.Location = new System.Drawing.Point(228, 298);
            this.txtAIRPF.Name = "txtAIRPF";
            this.txtAIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtAIRPF.TabIndex = 19;
            // 
            // txtDINSS
            // 
            this.txtDINSS.Enabled = false;
            this.txtDINSS.Location = new System.Drawing.Point(483, 271);
            this.txtDINSS.Name = "txtDINSS";
            this.txtDINSS.Size = new System.Drawing.Size(100, 20);
            this.txtDINSS.TabIndex = 20;
            // 
            // txtDIRPF
            // 
            this.txtDIRPF.Enabled = false;
            this.txtDIRPF.Location = new System.Drawing.Point(483, 298);
            this.txtDIRPF.Name = "txtDIRPF";
            this.txtDIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtDIRPF.TabIndex = 21;
            // 
            // txtSalFam
            // 
            this.txtSalFam.Enabled = false;
            this.txtSalFam.Location = new System.Drawing.Point(228, 342);
            this.txtSalFam.Name = "txtSalFam";
            this.txtSalFam.Size = new System.Drawing.Size(100, 20);
            this.txtSalFam.TabIndex = 22;
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Location = new System.Drawing.Point(483, 342);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.Size = new System.Drawing.Size(100, 20);
            this.txtSalLiq.TabIndex = 23;
            // 
            // CalculoSalario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.txtSalFam);
            this.Controls.Add(this.txtDIRPF);
            this.Controls.Add(this.txtDINSS);
            this.Controls.Add(this.txtAIRPF);
            this.Controls.Add(this.txtAINSS);
            this.Controls.Add(this.lblDIRPF);
            this.Controls.Add(this.lblDINSS);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.lblSalFam);
            this.Controls.Add(this.lblAIRPF);
            this.Controls.Add(this.lblAInss);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gBoxSexo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.mtxtSalario);
            this.Controls.Add(this.cmboxFilhos);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Name = "CalculoSalario";
            this.Text = "Calculo Salário";
            this.Load += new System.EventHandler(this.CalculoSalario_Load);
            this.gBoxSexo.ResumeLayout(false);
            this.gBoxSexo.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.ComboBox cmboxFilhos;
        private System.Windows.Forms.MaskedTextBox mtxtSalario;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.GroupBox gBoxSexo;
        private System.Windows.Forms.RadioButton rbtnMasculino;
        private System.Windows.Forms.RadioButton rbtnFeminino;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox cboxCasado;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Label lblAInss;
        private System.Windows.Forms.Label lblAIRPF;
        private System.Windows.Forms.Label lblSalFam;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.Label lblDINSS;
        private System.Windows.Forms.Label lblDIRPF;
        private System.Windows.Forms.TextBox txtAINSS;
        private System.Windows.Forms.TextBox txtAIRPF;
        private System.Windows.Forms.TextBox txtDINSS;
        private System.Windows.Forms.TextBox txtDIRPF;
        private System.Windows.Forms.TextBox txtSalFam;
        private System.Windows.Forms.TextBox txtSalLiq;
    }
}

