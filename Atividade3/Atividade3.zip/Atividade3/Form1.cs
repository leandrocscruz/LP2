﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade3
{
    public partial class Form1 : Form
    {
        double altura, calcpeso, peso;

    public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtPeso.Text = "";
           
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            altura = Convert.ToDouble(txtAltura.Text);
            peso = Convert.ToDouble(txtPeso.Text);
            if ((rbtnFeminino.Checked) || (rbtnMasculino.Checked))
            {
                if (rbtnFeminino.Checked)
                    calcpeso = (62.1 * altura)- 44.7;
                else
                   calcpeso = (72.7 * altura) - 58;
            }
            else
                MessageBox.Show("Selecione o Sexo");
            calcpeso = Math.Round(calcpeso,2);
           peso =  Math.Round(peso,2);
            if (calcpeso == peso)
                MessageBox.Show("Parabéns !!!\nPeso ideal\n"+"Seu Peso: "+peso+"\n"+"Peso ideal: "+calcpeso);
            if (peso < calcpeso)
                MessageBox.Show("Precisa se alimentar mais !!!\nPeso abaixo do ideal !!!\n" + "Seu Peso: " + peso + "\n" + "Peso ideal: " + calcpeso);
            if (peso > calcpeso)
                MessageBox.Show("Precisa de regime urgente !!!\nPeso acima do ideal !!!\n" + "Seu Peso: " + peso + "\n" + "Peso ideal: " + calcpeso);

        }
    }
}
