﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {

            if ((txtLadoA.Text != "") && (txtLadoB.Text != "") && (txtLadoC.Text != "")&&
                (Double.TryParse(txtLadoA.Text, out LadoA))&&(Double.TryParse(txtLadoB.Text, out LadoB))
                &&(Double.TryParse(txtLadoC.Text, out LadoC)))
            {
                LadoA = Convert.ToDouble(txtLadoA.Text);
                LadoB = Convert.ToDouble(txtLadoB.Text);
                LadoC = Convert.ToDouble(txtLadoC.Text);


                if (((LadoB-LadoC)<LadoA)&&(LadoA<(LadoB+LadoC))&& ((LadoA - LadoC) < LadoB)&&(LadoB < (LadoA + LadoC))
                    &&((LadoA - LadoB) < LadoC) && (LadoC < (LadoA + LadoC)))
                {
                    if ((LadoA == LadoB) || (LadoA == LadoC) || (LadoC == LadoB))
                        MessageBox.Show("Triângulo Isóceles");
                    if ((LadoA == LadoB) && (LadoA == LadoC) && (LadoB == LadoC))
                        MessageBox.Show("Triângulo Equilatero");
                    if ((LadoA != LadoB) && (LadoA != LadoC) && (LadoB != LadoC))
                        MessageBox.Show("Triângulo Escaleno");
                }
            }
            else
            {
                MessageBox.Show("Informe os Valores dos Lados");
              
            }
           

        }
    }
}
