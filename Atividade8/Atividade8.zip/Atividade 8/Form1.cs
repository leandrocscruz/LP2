﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite o Número: " + (i + 1), "Entrada de dados");
                if (!(int.TryParse(auxiliar, out vetor[i])))
                {
                    MessageBox.Show("Número Inválido");
                    i--;

                }
            }

            auxiliar = "";
            for (var i = vetor.Length - 1; i >= 0; i--)
                auxiliar += vetor[i].ToString() + "\n";
            MessageBox.Show(auxiliar);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void btnExercicio6_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[20, 3];
            string auxiliar = "";
            double media = 0;
            for (int i = 0; i < 20; i++)

            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a Nota " + (j + 1).ToString() +
                        " do Aluno " + (i + 1).ToString(), "Entrada de Dados");
                    if ((double.TryParse(auxiliar, out matriz[i, j])) &&
                            (matriz[i, j] >= 0))
                    {
                        media += matriz[i, j];
                    }
                    else
                    {
                        MessageBox.Show("Nota Inválida!");
                        j--;
                    }
                }
                MessageBox.Show("Aluno " + (i + 1).ToString() + "Média " + (media / 3).ToString("N2"));

            }
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite o Número: " + (i + 1), "Entrada de dados");
                if (!(int.TryParse(auxiliar, out vetor[i])))
                {
                    MessageBox.Show("Número Inválido");
                    i--;

                }

            }
            auxiliar = "";
            for (var i = vetor.Length - 1; i >= 0; i--)
                auxiliar += vetor[i].ToString() + "\n";



            MessageBox.Show(auxiliar);
            //MessageBox.Show(vetor.ToString());
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,,] vetor = new double[31, 10, 2];
            string auxiliar = "";
            double faturamento = 0;
            double valor = 0;
            double qtde = 0;

            for (int i = 0; i < 31; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    for (int x = 0; x < 1; x++)
                    {
                        auxiliar = Interaction.InputBox("Para o produto " + (j + 1).ToString()
                                   + " informe o valor do produto no dia " + (i + 1).ToString(), "Entrada de dados");
                        if ((double.TryParse(auxiliar, out vetor[i, j, x])) && (vetor[i, j, x] >= 0))
                        {
                            valor = vetor[i, j, x];
                        }
                        else
                        {
                            MessageBox.Show("Número Inválido !");
                            x--;
                        }
                        auxiliar = Interaction.InputBox("Para o produto " + (j + 1).ToString()
                                + " informe a quantidade vendida no dia " + (i + 1).ToString(), "Entrada de dados");
                        if ((double.TryParse(auxiliar, out vetor[i, j, x + 1])) && (vetor[i, j, x + 1] >= 0))
                        {
                            qtde = vetor[i, j, x + 1];
                        }
                        else
                        {
                            MessageBox.Show("Número Inválido! ");
                            x--;
                        }
                        faturamento += valor * qtde;
                    }

                }
            }
            MessageBox.Show("Faturamento mensal: "+faturamento.ToString("N2"));
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I=0;I<N-1;I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show("Resultado "+Total.ToString());
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            string text = "";
            string[] Alunos = { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            for(int i=0;i<Alunos.Length-1;i++)
            {
                if (Alunos[i]!="Otávio")
                {
                    text += Alunos[i]+" ";
                }
            }
            MessageBox.Show(text);
        }

        private void btnExercicio7_Click(object sender, EventArgs e)
        {
            ListBox listbox1 = new ListBox();
            int n, espaco=0;
            string auxiliar = "";
            string nome = "";
            string contEsp = " ";
            string[] vetor = new string[10];
            int[] esp = new int[100];

            auxiliar = Interaction.InputBox("Informe seu RA ", "Entrada de Dados");      
            //n = auxiliar.Substring(auxiliar.Length - 1);
            if (int.TryParse(auxiliar, out n))
            {
                n = Convert.ToInt32(auxiliar.Substring(auxiliar.Length - 1));
                if (n == 0)
                {
                    n = 10;
                }
                for (int i = 0; i < n; i++)
                {
                    nome = Interaction.InputBox("Digite o " + (i + 1) + "º nome completo" + "\n" + "Total de Nomes " + n, "Entrada de Dados");
                    contEsp = nome.ToString();
                    espaco = nome.ToUpper().IndexOf(' ');
                    while (espaco > 0)
                    {
                        nome = nome.Substring(0, espaco) +
                            nome.Substring(espaco + 1, nome.Length - espaco - 1);
                        espaco = nome.ToUpper().IndexOf(' ');
                    }
                    vetor[i] = contEsp.ToString();
                    esp[i] = nome.Length;
                   
                   
                    //listbox1.Size = new System.Drawing.Size(300, 400);
                    //listbox1.Location = new System.Drawing.Point(100, 100);
                    listbox1.Items.Add("Nome " + vetor[i] + " - possui " + esp[i] + " caracteres!");
                }
                this.Controls.Add(listbox1);
                listbox1.Size = new System.Drawing.Size(300, 400);
            }
            else
            {
                MessageBox.Show("Digite apenas numero no RA");
            }
        }

    }
}
