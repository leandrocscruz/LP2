﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string palin;
            int posicao = 0;
            //txtPalindromo.Text = txtPalindromo.Text.ToUpper();

            //posicao = txtPalindromo.Text.IndexOf(' ');
            //while (posicao > 0)
            //{
            //    txtPalindromo.Text = txtPalindromo.Text.Substring(0, posicao) + 
            //        txtPalindromo.Text.Substring(posicao + 1, txtPalindromo.Text.Length - posicao - 1);
            //    posicao = txtPalindromo.Text.IndexOf(' ');
            //}
            //MessageBox.Show("Test " + txtPalindromo.Text.ToString());
            palin = txtPalindromo.Text.ToUpper();
            posicao = palin.IndexOf(' ');
            while (posicao >0)
            {
                palin = palin.Substring(0, posicao) +
                    palin.Substring(posicao + 1, palin.Length - posicao - 1);
                posicao = palin.IndexOf(' ');
            }
            string s = palin;
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            s = "";
            foreach (char c in arr)
            {
                s = s + c.ToString();
            }
            //MessageBox.Show("Test "+ s);
            if (palin == s)
            {
                MessageBox.Show("É Palíndromo !!!\n" + palin + "\n" + s);
            }
            else
                MessageBox.Show("Não é Palíndromo !!!\n" + palin + "\n" + s);

        }
    }
}
