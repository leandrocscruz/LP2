﻿namespace Atividade7
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxt = new System.Windows.Forms.RichTextBox();
            this.btnContaEsp = new System.Windows.Forms.Button();
            this.btnContaR = new System.Windows.Forms.Button();
            this.btnContaPares = new System.Windows.Forms.Button();
            this.btnVoltar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxt
            // 
            this.rchTxt.Location = new System.Drawing.Point(224, 99);
            this.rchTxt.MaxLength = 100;
            this.rchTxt.Name = "rchTxt";
            this.rchTxt.Size = new System.Drawing.Size(350, 96);
            this.rchTxt.TabIndex = 0;
            this.rchTxt.Text = "";
            // 
            // btnContaEsp
            // 
            this.btnContaEsp.Location = new System.Drawing.Point(199, 260);
            this.btnContaEsp.Name = "btnContaEsp";
            this.btnContaEsp.Size = new System.Drawing.Size(92, 53);
            this.btnContaEsp.TabIndex = 1;
            this.btnContaEsp.Text = "Conta Espaço em Branco";
            this.btnContaEsp.UseVisualStyleBackColor = true;
            this.btnContaEsp.Click += new System.EventHandler(this.btnContaEsp_Click);
            // 
            // btnContaR
            // 
            this.btnContaR.Location = new System.Drawing.Point(329, 260);
            this.btnContaR.Name = "btnContaR";
            this.btnContaR.Size = new System.Drawing.Size(85, 53);
            this.btnContaR.TabIndex = 2;
            this.btnContaR.Text = "Conta Letra R";
            this.btnContaR.UseVisualStyleBackColor = true;
            this.btnContaR.Click += new System.EventHandler(this.btnContaR_Click);
            // 
            // btnContaPares
            // 
            this.btnContaPares.Location = new System.Drawing.Point(464, 260);
            this.btnContaPares.Name = "btnContaPares";
            this.btnContaPares.Size = new System.Drawing.Size(85, 53);
            this.btnContaPares.TabIndex = 3;
            this.btnContaPares.Text = "Conta Pares de Letras";
            this.btnContaPares.UseVisualStyleBackColor = true;
            this.btnContaPares.Click += new System.EventHandler(this.btnContaPares_Click);
            // 
            // btnVoltar
            // 
            this.btnVoltar.Location = new System.Drawing.Point(357, 355);
            this.btnVoltar.Name = "btnVoltar";
            this.btnVoltar.Size = new System.Drawing.Size(75, 23);
            this.btnVoltar.TabIndex = 4;
            this.btnVoltar.Text = "Voltar";
            this.btnVoltar.UseVisualStyleBackColor = true;
            this.btnVoltar.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnVoltar);
            this.Controls.Add(this.btnContaPares);
            this.Controls.Add(this.btnContaR);
            this.Controls.Add(this.btnContaEsp);
            this.Controls.Add(this.rchTxt);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxt;
        private System.Windows.Forms.Button btnContaEsp;
        private System.Windows.Forms.Button btnContaR;
        private System.Windows.Forms.Button btnContaPares;
        private System.Windows.Forms.Button btnVoltar;
    }
}