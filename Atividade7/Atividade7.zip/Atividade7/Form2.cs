﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnContaR_Click(object sender, EventArgs e)
        {
            //int contaR = 0;
            //foreach(char c in rchTxt.Text.ToUpper())
            //{   
            //    if (Char.ToUpper(c) == 'R')
            //        contaR++;
            //}
            int contaR = 0;
            for (int i =0; i < rchTxt.Text.Length; i++)
            {
                if (rchTxt.Text[i] == 'r' || rchTxt.Text[i] == 'R')
                    contaR++;
            }
            MessageBox.Show("O número de letras R é: "+contaR.ToString());
        }

        private void btnContaPares_Click(object sender, EventArgs e)
        {
            int contaRep = 0;
            char LetraAnt = '\0';
            foreach (char c in rchTxt.Text)
            {
                if (Char.ToUpper(c) == LetraAnt)
                {
                    contaRep++;
                }
                LetraAnt = Char.ToUpper(c);
            }
            MessageBox.Show("O número de letras repetidas é: " + contaRep.ToString());
        }

        private void btnContaEsp_Click(object sender, EventArgs e)
        {
            int contaEsp = 0;
            
            foreach (char c in rchTxt.Text.ToUpper())
            {
                if (Char.ToUpper(c) == ' ')
                    contaEsp++;
            }
            MessageBox.Show("O número de espaços em branco é: " + contaEsp.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();

        }
    }
}
