﻿namespace Atividade7
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExer1 = new System.Windows.Forms.Button();
            this.btnExer2 = new System.Windows.Forms.Button();
            this.btnExer3 = new System.Windows.Forms.Button();
            this.btnExer4 = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExer1
            // 
            this.btnExer1.Location = new System.Drawing.Point(80, 286);
            this.btnExer1.Name = "btnExer1";
            this.btnExer1.Size = new System.Drawing.Size(113, 62);
            this.btnExer1.TabIndex = 0;
            this.btnExer1.Text = "Exercício 1";
            this.btnExer1.UseVisualStyleBackColor = true;
            this.btnExer1.Click += new System.EventHandler(this.btnExer1_Click);
            // 
            // btnExer2
            // 
            this.btnExer2.Location = new System.Drawing.Point(231, 286);
            this.btnExer2.Name = "btnExer2";
            this.btnExer2.Size = new System.Drawing.Size(113, 62);
            this.btnExer2.TabIndex = 1;
            this.btnExer2.Text = "Exercício 2";
            this.btnExer2.UseVisualStyleBackColor = true;
            this.btnExer2.Click += new System.EventHandler(this.btnExer2_Click);
            // 
            // btnExer3
            // 
            this.btnExer3.Location = new System.Drawing.Point(375, 286);
            this.btnExer3.Name = "btnExer3";
            this.btnExer3.Size = new System.Drawing.Size(113, 62);
            this.btnExer3.TabIndex = 2;
            this.btnExer3.Text = "Exercício 3";
            this.btnExer3.UseVisualStyleBackColor = true;
            this.btnExer3.Click += new System.EventHandler(this.btnExer3_Click);
            // 
            // btnExer4
            // 
            this.btnExer4.Location = new System.Drawing.Point(518, 286);
            this.btnExer4.Name = "btnExer4";
            this.btnExer4.Size = new System.Drawing.Size(113, 62);
            this.btnExer4.TabIndex = 3;
            this.btnExer4.Text = "Exercício 4";
            this.btnExer4.UseVisualStyleBackColor = true;
            this.btnExer4.Click += new System.EventHandler(this.btnExer4_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(344, 375);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 4;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnExer4);
            this.Controls.Add(this.btnExer3);
            this.Controls.Add(this.btnExer2);
            this.Controls.Add(this.btnExer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExer1;
        private System.Windows.Forms.Button btnExer2;
        private System.Windows.Forms.Button btnExer3;
        private System.Windows.Forms.Button btnExer4;
        private System.Windows.Forms.Button btnSair;
    }
}

