﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            double H=0;
            int Calc = 0;
            //int x = 0;

            Int32.TryParse(txtCalc.Text, out Calc);
            if (Calc == 0)
                MessageBox.Show("Digite apenas numeros \nMaior que zero");
            else
            {
               // MessageBox.Show("Calc = "+Calc.ToString());
                for (double i = 1; i <= Calc; i++)
                {
                    H += 1/i;
                    //x++;
                }
                H = Math.Round(H, 4);
                MessageBox.Show("O Resultado de H é: "+ H);
            }
        }
    }
}
