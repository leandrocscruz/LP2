﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P_Metodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void btnNumerico_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int numeros = 0;
            for (contador = 0; contador<rchTxt.Text.Length;contador++)
            {
                if (Char.IsNumber(rchTxt.Text[contador]))
                {
                    numeros += 1;
                }
            }
            MessageBox.Show("A quantidade de números é: " + numeros.ToString());
        }

        private void btnPosicao_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int posicao = 0;
            while (contador<rchTxt.Text.Length)
            {
                if (Char.IsWhiteSpace(rchTxt.Text[contador]))
                {
                    posicao = contador;
                    break;
                }
                contador++;

            }
            MessageBox.Show("O primeiro caracter em branco está na posição: "+ posicao.ToString());
        }

        private void btnAlfabeticos_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char chara in rchTxt.Text)
            {
                if (Char.IsLetter(chara))
                {
                    contador += 1;

                }
            }
            MessageBox.Show("O texto tem "+ contador.ToString()+ " caractere(s) alfabético(s)");
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            rchTxt.Text = "";
            Form fc = Application.OpenForms["Form1"];
            if (fc != null)
                fc.Close();

            FrmPrincipal form1 = new FrmPrincipal();
            form1.WindowState = FormWindowState.Maximized;
            form1.Show();
        }
    }
}
