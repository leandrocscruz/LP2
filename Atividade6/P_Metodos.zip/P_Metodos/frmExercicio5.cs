﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P_Metodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void frmExercicio5_Load(object sender, EventArgs e)
        {

        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = "";
            txtNumero2.Text = "";
            Form fc = Application.OpenForms["Form1"];
            if (fc != null)
                fc.Close();

            FrmPrincipal form1 = new FrmPrincipal();
            form1.WindowState = FormWindowState.Maximized;
            form1.Show();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int numero1 = 0;
            int numero2 = 0;
            if ((int.TryParse(txtNumero1.Text, out numero1))&&(int.TryParse(txtNumero2.Text, out numero2)))
            {
                if (numero1 >= numero2)
                    MessageBox.Show("O primeiro número deve ser menor");
                else
                {
                    Random random = new Random();
                    double r = random.Next(numero1, numero2);
                    MessageBox.Show("O número sorteado é: " + r.ToString());
                }
            }
            else
                MessageBox.Show("Digite somente números !!!");
        }
    }
}
