﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482013029
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int n = 0,z=0,x=0;
            string auxiliar = "";
            double venda = 0, qtde = 0,totalmes=0,totalsemana=0;
            double[,,] total = new double[11, 4, 9];
            double[] totalvendas = new double[11];

            auxiliar = Interaction.InputBox("Informe seu RA ", "Entrada de Dados");
            if (int.TryParse(auxiliar, out n))
            {
                n = Convert.ToInt32(auxiliar.Substring(auxiliar.Length - 1));
                if (n == 0)
                {
                    n = 10;
                }
                for (int i = 0; i < 12; i++)
                {
                    totalmes = 0;
                    for (x = 0; x < 4; x++)
                    {
                        totalsemana = 0;
                        for (z = 0; z <= n-1; z++)
                        {
                            qtde = Convert.ToDouble(Interaction.InputBox("Mês " + (i + 1) + " Semana " + (x + 1) + "\n" + "Digite a quantidade de vendas do " + (z + 1) + "º item vendido" + "\n", "Entrada de Dados"));
                            venda = Convert.ToDouble(Interaction.InputBox("Mês " + (i + 1) + " Semana " + (x + 1) + "\n" + "Digite o valor do " + (z + 1) + "º item vendido" + "\n", "Entrada de Dados"));
                            totalsemana += qtde * venda;
                        }
                        total[i, x, z] = totalsemana;
                        totalmes += totalsemana;
                        lBox1.Items.Add("Total do Mês: " + (i + 1) + " Semana: " + (x + 1) +"   "+ total[i,x,z].ToString("C2"));

                    }
                    totalvendas[i] = totalmes;
                    lBox1.Items.Add(">>>>>> Total Mês: " + (i + 1) + "   " + totalvendas[i].ToString("C2"));
                    lBox1.Items.Add("..........................");
                }
            }
            else
            {
                MessageBox.Show("Digite apenas numero no RA");
            }
        }
    }

}

